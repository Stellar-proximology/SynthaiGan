import { useState } from "react";
import { Settings, FileCode, Bot, Smartphone, Globe, MessageSquare, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import { BrowserBar } from "@/components/BrowserBar";
import { BrowserView } from "@/components/BrowserView";
import { CodeEditor } from "@/components/CodeEditor";
import { ViewModeToggle, ViewMode } from "@/components/ViewModeToggle";
import { SettingsPanel } from "@/components/SettingsPanel";
import { DeployModal } from "@/components/DeployModal";
import { AIAssistPanel } from "@/components/AIAssistPanel";
import { TemplateLibrary } from "@/components/TemplateLibrary";
import { AgentCreator } from "@/components/AgentCreator";
import { APKBuilder } from "@/components/APKBuilder";
import { PlainEnglishBuilder } from "@/components/PlainEnglishBuilder";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function Home() {
  const [viewMode, setViewMode] = useState<ViewMode>("browser");
  const [currentUrl, setCurrentUrl] = useState("https://www.example.com");
  const [showSettings, setShowSettings] = useState(false);
  const [showDeploy, setShowDeploy] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showAgentCreator, setShowAgentCreator] = useState(false);
  const [showAPKBuilder, setShowAPKBuilder] = useState(false);
  const [showPlainEnglish, setShowPlainEnglish] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavigate = (url: string) => {
    setCurrentUrl(url);
  };

  const handleCodeDetected = (code: string) => {
    console.log("Code extracted:", code);
    setViewMode("code");
  };

  const handleExport = () => {
    console.log("Export project");
  };

  const handleSelectTemplate = (template: any) => {
    console.log("Selected template:", template);
    setShowTemplates(false);
    setViewMode("code");
  };

  const handleGenerateCode = (description: string) => {
    console.log("Generating code from:", description);
    setShowPlainEnglish(false);
    setViewMode("code");
  };

  return (
    <div className="h-screen w-full flex flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between gap-2 sm:gap-4 p-2 sm:p-3 border-b bg-card">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Globe className="h-5 w-5 text-primary" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-sm font-semibold">CodeBrowse</h1>
              <p className="text-xs text-muted-foreground">You-N-I-Verse Edition</p>
            </div>
          </div>
        </div>

        <div className="hidden lg:flex">
          <ViewModeToggle mode={viewMode} onChange={setViewMode} />
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowPlainEnglish(true)}
            data-testid="button-plain-english"
          >
            <MessageSquare className="h-4 w-4 sm:mr-2" />
            <span className="hidden sm:inline">Describe Idea</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowTemplates(true)}
            data-testid="button-templates"
          >
            <FileCode className="h-4 w-4 sm:mr-2" />
            <span className="hidden xl:inline">Templates</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAgentCreator(true)}
            data-testid="button-agent-creator"
          >
            <Bot className="h-4 w-4 sm:mr-2" />
            <span className="hidden xl:inline">Agents</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAPKBuilder(true)}
            data-testid="button-apk-builder"
          >
            <Smartphone className="h-4 w-4 sm:mr-2" />
            <span className="hidden xl:inline">Build APK</span>
          </Button>
          <ThemeToggle />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowSettings(true)}
            data-testid="button-settings"
          >
            <Settings className="h-5 w-5" />
          </Button>
        </div>

        {/* Mobile Menu */}
        <div className="flex md:hidden items-center gap-1">
          <ThemeToggle />
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <div className="flex flex-col gap-4 mt-6">
                <div className="lg:hidden mb-4">
                  <ViewModeToggle mode={viewMode} onChange={setViewMode} />
                </div>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    setShowPlainEnglish(true);
                    setMobileMenuOpen(false);
                  }}
                  data-testid="button-mobile-plain-english"
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Describe Your Idea
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    setShowTemplates(true);
                    setMobileMenuOpen(false);
                  }}
                  data-testid="button-mobile-templates"
                >
                  <FileCode className="h-4 w-4 mr-2" />
                  Templates
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    setShowAgentCreator(true);
                    setMobileMenuOpen(false);
                  }}
                  data-testid="button-mobile-agents"
                >
                  <Bot className="h-4 w-4 mr-2" />
                  Agent Creator
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    setShowAPKBuilder(true);
                    setMobileMenuOpen(false);
                  }}
                  data-testid="button-mobile-apk"
                >
                  <Smartphone className="h-4 w-4 mr-2" />
                  Build APK
                </Button>
                <Button
                  variant="outline"
                  className="justify-start"
                  onClick={() => {
                    setShowSettings(true);
                    setMobileMenuOpen(false);
                  }}
                  data-testid="button-mobile-settings"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Browser View */}
        {(viewMode === "browser" || viewMode === "split") && (
          <div className={`flex flex-col ${viewMode === "split" ? "w-full md:w-1/2 md:border-r" : "w-full"}`}>
            <BrowserBar onNavigate={handleNavigate} currentUrl={currentUrl} />
            <div className="flex-1 overflow-hidden">
              <BrowserView url={currentUrl} onCodeDetected={handleCodeDetected} />
            </div>
          </div>
        )}

        {/* Code Editor View */}
        {(viewMode === "code" || viewMode === "split") && (
          <div className={`flex flex-col ${viewMode === "split" ? "w-full md:w-1/2" : "w-full"}`}>
            <CodeEditor
              onDeploy={() => setShowDeploy(true)}
              onExport={handleExport}
              onAIAssist={() => setShowAI(true)}
            />
          </div>
        )}
      </div>

      {/* Modals & Panels */}
      <SettingsPanel isOpen={showSettings} onClose={() => setShowSettings(false)} />
      <DeployModal isOpen={showDeploy} onClose={() => setShowDeploy(false)} />
      <AIAssistPanel isOpen={showAI} onClose={() => setShowAI(false)} />
      <TemplateLibrary
        isOpen={showTemplates}
        onClose={() => setShowTemplates(false)}
        onSelectTemplate={handleSelectTemplate}
      />
      <AgentCreator isOpen={showAgentCreator} onClose={() => setShowAgentCreator(false)} />
      <APKBuilder isOpen={showAPKBuilder} onClose={() => setShowAPKBuilder(false)} />
      
      {/* Plain English Builder Modal */}
      {showPlainEnglish && (
        <>
          <div
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
            onClick={() => setShowPlainEnglish(false)}
            data-testid="plain-english-backdrop"
          />
          <div className="fixed inset-x-4 sm:left-1/2 sm:-translate-x-1/2 top-4 sm:top-1/2 sm:-translate-y-1/2 w-auto sm:w-full sm:max-w-2xl h-[calc(100vh-2rem)] sm:h-[85vh] bg-card border rounded-lg z-50 overflow-hidden">
            <PlainEnglishBuilder 
              onGenerateCode={handleGenerateCode}
              onClose={() => setShowPlainEnglish(false)}
            />
          </div>
        </>
      )}
    </div>
  );
}
