# Photonic QGANs for classical data

This repository contains the code for the paper [Photonic quantum generative adversarial networks for classical data](https://arxiv.org/abs/2405.06023).

The code was written by Tigran Sedrakyan, under the supervision of Alexia Salavrakos.
