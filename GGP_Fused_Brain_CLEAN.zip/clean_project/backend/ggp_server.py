#!/usr/bin/env python3
"""
GGP Flask Server
Handles file uploads, zip creation, code execution, and consciousness tools
"""

from flask import Flask, request, jsonify, send_file, render_template_string
from flask_cors import CORS
import os
import zipfile
import io
import subprocess
import json
from datetime import datetime
from pathlib import Path
import tempfile
import shutil

app = Flask(__name__)
CORS(app)  # Enable CORS for browser access

# Configuration
UPLOAD_FOLDER = Path('uploads')
PROJECTS_FOLDER = Path('projects')
TEMP_FOLDER = Path('temp')

# Create folders if they don't exist
UPLOAD_FOLDER.mkdir(exist_ok=True)
PROJECTS_FOLDER.mkdir(exist_ok=True)
TEMP_FOLDER.mkdir(exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

# Store active projects
projects = {}


@app.route('/')
def home():
    """API status endpoint"""
    return jsonify({
        'status': 'online',
        'name': 'GGP Server',
        'version': '1.0.0',
        'consciousness_fields': 'active',
        'endpoints': {
            'upload': '/api/upload',
            'run_code': '/api/run',
            'create_zip': '/api/zip/create',
            'download_zip': '/api/zip/download/<project_id>',
            'list_files': '/api/files',
            'save_code': '/api/save',
            'git_push': '/api/git/push'
        }
    })


@app.route('/api/upload', methods=['POST'])
def upload_file():
    """
    Upload single or multiple files
    Supports: images, code files, documents, etc.
    """
    if 'files' not in request.files:
        return jsonify({'error': 'No files provided'}), 400
    
    files = request.files.getlist('files')
    uploaded_files = []
    
    for file in files:
        if file.filename == '':
            continue
        
        # Create safe filename
        filename = Path(file.filename).name
        filepath = UPLOAD_FOLDER / filename
        
        # Save file
        file.save(filepath)
        
        uploaded_files.append({
            'filename': filename,
            'size': filepath.stat().st_size,
            'path': str(filepath),
            'uploaded_at': datetime.now().isoformat()
        })
    
    return jsonify({
        'success': True,
        'message': f'Uploaded {len(uploaded_files)} file(s)',
        'files': uploaded_files
    })


@app.route('/api/upload/zip', methods=['POST'])
def upload_and_extract_zip():
    """
    Upload a zip file and extract its contents
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if not file.filename.endswith('.zip'):
        return jsonify({'error': 'File must be a .zip'}), 400
    
    # Save zip temporarily
    zip_path = TEMP_FOLDER / file.filename
    file.save(zip_path)
    
    # Extract
    extract_folder = UPLOAD_FOLDER / Path(file.filename).stem
    extract_folder.mkdir(exist_ok=True)
    
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_folder)
    
    # Clean up temp zip
    zip_path.unlink()
    
    # List extracted files
    extracted_files = []
    for root, dirs, files in os.walk(extract_folder):
        for f in files:
            extracted_files.append(str(Path(root) / f))
    
    return jsonify({
        'success': True,
        'message': 'Zip extracted',
        'extract_folder': str(extract_folder),
        'files': extracted_files
    })


@app.route('/api/zip/create', methods=['POST'])
def create_zip():
    """
    Create a zip file from specified files or folders
    Body: {
        "project_id": "my_project",
        "files": ["path/to/file1.py", "path/to/file2.py"],
        "folders": ["path/to/folder"]
    }
    """
    data = request.json
    project_id = data.get('project_id', f'project_{datetime.now().strftime("%Y%m%d_%H%M%S")}')
    files = data.get('files', [])
    folders = data.get('folders', [])
    
    # Create zip in memory
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add individual files
        for file_path in files:
            path = Path(file_path)
            if path.exists():
                zip_file.write(path, path.name)
        
        # Add folders
        for folder_path in folders:
            folder = Path(folder_path)
            if folder.exists() and folder.is_dir():
                for root, dirs, files_in_folder in os.walk(folder):
                    for file in files_in_folder:
                        file_path = Path(root) / file
                        arcname = file_path.relative_to(folder.parent)
                        zip_file.write(file_path, arcname)
    
    # Save zip file
    zip_path = PROJECTS_FOLDER / f'{project_id}.zip'
    with open(zip_path, 'wb') as f:
        f.write(zip_buffer.getvalue())
    
    projects[project_id] = {
        'created_at': datetime.now().isoformat(),
        'path': str(zip_path),
        'size': zip_path.stat().st_size
    }
    
    return jsonify({
        'success': True,
        'project_id': project_id,
        'download_url': f'/api/zip/download/{project_id}',
        'size': zip_path.stat().st_size
    })


@app.route('/api/zip/download/<project_id>')
def download_zip(project_id):
    """Download a created zip file"""
    if project_id not in projects:
        return jsonify({'error': 'Project not found'}), 404
    
    zip_path = projects[project_id]['path']
    
    return send_file(
        zip_path,
        mimetype='application/zip',
        as_attachment=True,
        download_name=f'{project_id}.zip'
    )


@app.route('/api/run', methods=['POST'])
def run_code():
    """
    Execute Python code safely
    Body: {
        "code": "print('hello')",
        "timeout": 5
    }
    """
    data = request.json
    code = data.get('code', '')
    timeout = data.get('timeout', 5)
    
    if not code:
        return jsonify({'error': 'No code provided'}), 400
    
    # Create temporary Python file
    temp_file = TEMP_FOLDER / f'exec_{datetime.now().timestamp()}.py'
    temp_file.write_text(code)
    
    try:
        # Run code with timeout
        result = subprocess.run(
            ['python3', str(temp_file)],
            capture_output=True,
            text=True,
            timeout=timeout
        )
        
        output = {
            'success': True,
            'stdout': result.stdout,
            'stderr': result.stderr,
            'returncode': result.returncode
        }
        
    except subprocess.TimeoutExpired:
        output = {
            'success': False,
            'error': 'Execution timeout',
            'timeout': timeout
        }
    except Exception as e:
        output = {
            'success': False,
            'error': str(e)
        }
    finally:
        # Clean up
        if temp_file.exists():
            temp_file.unlink()
    
    return jsonify(output)


@app.route('/api/save', methods=['POST'])
def save_code():
    """
    Save code to a file
    Body: {
        "filename": "consciousness_field.py",
        "code": "# code here",
        "folder": "my_project"
    }
    """
    data = request.json
    filename = data.get('filename', 'untitled.py')
    code = data.get('code', '')
    folder = data.get('folder', 'default')
    
    # Create project folder
    project_folder = PROJECTS_FOLDER / folder
    project_folder.mkdir(exist_ok=True)
    
    # Save file
    file_path = project_folder / filename
    file_path.write_text(code)
    
    return jsonify({
        'success': True,
        'message': 'File saved',
        'path': str(file_path),
        'size': file_path.stat().st_size
    })


@app.route('/api/files', methods=['GET'])
def list_files():
    """List all uploaded files and projects"""
    uploaded_files = []
    project_files = []
    
    # List uploads
    for file_path in UPLOAD_FOLDER.rglob('*'):
        if file_path.is_file():
            uploaded_files.append({
                'name': file_path.name,
                'path': str(file_path.relative_to(UPLOAD_FOLDER)),
                'size': file_path.stat().st_size,
                'modified': datetime.fromtimestamp(file_path.stat().st_mtime).isoformat()
            })
    
    # List projects
    for file_path in PROJECTS_FOLDER.rglob('*'):
        if file_path.is_file():
            project_files.append({
                'name': file_path.name,
                'path': str(file_path.relative_to(PROJECTS_FOLDER)),
                'size': file_path.stat().st_size,
                'modified': datetime.fromtimestamp(file_path.stat().st_mtime).isoformat()
            })
    
    return jsonify({
        'uploads': uploaded_files,
        'projects': project_files,
        'total_files': len(uploaded_files) + len(project_files)
    })


@app.route('/api/git/push', methods=['POST'])
def git_push():
    """
    Simulate Git push (you'll need to add real Git integration)
    Body: {
        "repo": "https://github.com/user/repo",
        "branch": "main",
        "message": "Update consciousness fields"
    }
    """
    data = request.json
    repo = data.get('repo', '')
    branch = data.get('branch', 'main')
    message = data.get('message', 'Update from GGP')
    
    # This is a simulation - add real Git integration here
    return jsonify({
        'success': True,
        'message': 'Push simulated',
        'repo': repo,
        'branch': branch,
        'commit_message': message,
        'note': 'Add real Git integration with GitPython or subprocess'
    })


@app.route('/api/consciousness/field', methods=['POST'])
def consciousness_field():
    """
    Example consciousness field calculation
    Body: {
        "field_type": "Mind",
        "chart_system": "sidereal"
    }
    """
    data = request.json
    field_type = data.get('field_type', 'Mind')
    chart_system = data.get('chart_system', 'sidereal')
    
    # Placeholder for real consciousness calculations
    import random
    coherence = random.uniform(0.5, 1.0)
    resonance = random.uniform(100, 1000)
    
    return jsonify({
        'field_type': field_type,
        'chart_system': chart_system,
        'coherence': coherence,
        'resonance': resonance,
        'timestamp': datetime.now().isoformat()
    })


if __name__ == '__main__':
    print("🌌 GGP Server Starting...")
    print(f"📁 Uploads: {UPLOAD_FOLDER.absolute()}")
    print(f"📁 Projects: {PROJECTS_FOLDER.absolute()}")
    print("✨ Consciousness fields active")
    print("🚀 Server running on http://localhost:5000")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
